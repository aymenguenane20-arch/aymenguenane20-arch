const { Client, GatewayIntentBits, ActionRowBuilder, ButtonBuilder, ButtonStyle, Events } = require('discord.js');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers
    ]
});

// --- CONFIGURATION ---
const config = {
    token: 'MTU1MjA5MDI1ODI2NTYxMjQyMg.GmrR5z.E_XYNi8zehyrcQtHGyo_hZq0yo7MwsJfNr2lmQ', 
    roles: {
        'btn_groupe_1': '1552427135229239378',
        'btn_groupe_2': '1552428066523975680',
        'btn_groupe_3': '1552428780180738048',
        'btn_groupe_4': '1552429174994632805'
    }
};

client.once(Events.ClientReady, readyClient => {
    console.log(`✅ Prêt ! Connecté en tant que ${readyClient.user.tag}`);
});

client.on(Events.MessageCreate, async message => {
    if (message.content === '!setup' && message.member.permissions.has('Administrator')) {
        
        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('btn_groupe_1')
                    .setLabel('Groupe 1')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('btn_groupe_2')
                    .setLabel('Groupe 2')
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId('btn_groupe_3')
                    .setLabel('Groupe 3')
                    .setStyle(ButtonStyle.Danger),
                new ButtonBuilder()
                    .setCustomId('btn_groupe_4')
                    .setLabel('Groupe 4')
                    .setStyle(ButtonStyle.Secondary),
            );

        await message.channel.send({
            content: '👋 **Dans quel groupe es-tu ?**\nClique sur un bouton ci-dessous pour recevoir ton rôle :',
            components: [row]
        });
        
        await message.delete(); 
    }
});

client.on(Events.InteractionCreate, async interaction => {
    if (!interaction.isButton()) return;

    const roleId = config.roles[interaction.customId];
    if (!roleId) return;

    const role = interaction.guild.roles.cache.get(roleId);
    const member = interaction.member;

    try {
        if (member.roles.cache.has(roleId)) {
            await member.roles.remove(roleId);
            await interaction.reply({ 
                content: `Le rôle **${role.name}** t'a été retiré.`, 
                ephemeral: true 
            });
        } 
        else {
            await member.roles.add(roleId);
            await interaction.reply({ 
                content: `Le rôle **${role.name}** t'a été attribué avec succès !`, 
                ephemeral: true 
            });
        }
    } catch (error) {
        console.error(error);
        await interaction.reply({ 
            content: "❌ Une erreur s'est produite. Vérifie que mon rôle est bien au-dessus des autres rôles dans les paramètres du serveur.", 
            ephemeral: true 
        });
    }
});

client.login(config.token);
DISPLAY_NAME=GroupBot
DESCRIPTION=Bot de roles
MAIN=index.js
MEMORY=100
VERSION=recommended